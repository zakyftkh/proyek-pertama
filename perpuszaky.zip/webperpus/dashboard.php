<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="desain.css">
    <link rel="stylesheet" href="css/bootstrap.css">
    
</head>
<body>
    <header class="bg-warning">
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Perpustakaan</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDarkDropdown" aria-controls="navbarNavDarkDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavDarkDropdown">
      <ul class="navbar-nav">
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
           Menu
          </a>
          <ul class="dropdown-menu dropdown-menu-dark">
          <li><a class="dropdown-item" href="dashboard.php">Dashboard</a></li>
            <li><a class="dropdown-item" href="form-buku.php">Buku</a></li>
            <li><a class="dropdown-item" href="form-member.php">Member</a></li>
            <li><a class="dropdown-item" href="form-pustakawan.php">Pustakawan</a></li>
            <li><a class="dropdown-item" href="form-peminjaman.php">Peminjaman</a></li>
          </ul>
        </li>
      </ul>
    </div>
  </div>
</nav>
    </header>
    <section>
    <div class="layer">
        
    </div>
    </section>
    <footer>

    </footer>
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

</body>
</html>