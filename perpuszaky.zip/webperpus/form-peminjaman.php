<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="desain.css">
    <link rel="stylesheet" href="css/bootstrap.css">
    
</head>
<body>
    <header class="bg-warning">
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Perpustakaan</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDarkDropdown" aria-controls="navbarNavDarkDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavDarkDropdown">
      <ul class="navbar-nav">
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
           Menu
          </a>
          <ul class="dropdown-menu dropdown-menu-dark">
          <li><a class="dropdown-item" href="dashboard.php">Dashboard</a></li>
            <li><a class="dropdown-item" href="form-buku.php">Buku</a></li>
            <li><a class="dropdown-item" href="form-member.php">Member</a></li>
            <li><a class="dropdown-item" href="form-pustakawan.php">Pustakawan</a></li>
            <li><a class="dropdown-item" href="form-peminjaman.php">Peminjaman</a></li>
          </ul>
        </li>
      </ul>
    </div>
  </div>
</nav>
    </header>
    <section>
    <div class="layer">
        <div class="tb">
        <h2>Data Peminjaman</h2>
<button type="button" class="btn btn-primary tmbl" data-bs-toggle="modal" data-bs-target="#tambah">
  Tambah Data Peminjaman
</button>
<div class="modal fade" id="tambah" tabindex="-1" aria-labelledby="tambah" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5 judul" id="tambah">Tambah Data Peminjaman</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <form method="post" action="simpan.php">
        <table class="table" >
            <tr>
                <td>Tanggal Pinjam</td>
                <td>:</td>
                <td>
                    <input class="form-control" type="date" name="pinjam_tgl" required>
                </td>
            </tr>
            <tr>
                <td>Jumlah Pinjam</td>
                <td>:</td>
                <td>
                    <input class="form-control" type="number" name="pinjam_jml" required>
                </td>
            </tr>
            <tr>
                <td>Tanggal Kembali</td>
                <td>:</td>
                <td>
                    <input class="form-control" type="date" name="kembali_tgl" required>
                </td>
            </tr>
            <tr>
                <td>Jumlah Kembali</td>
                <td>:</td>
                <td>
                    <input class="form-control" type="number" name="kembali_jml" required>
                </td>
            </tr>
            <tr>
                <td>Lama Pinjam</td>
                <td>:</td>
                <td>
                    <input class="form-control" type="number" name="lama_pinjam" required>
                </td>
            </tr>
            <tr>
                <td>Terlambat</td>
                <td>:</td>
                <td>
                    <input class="form-control" type="number" name="terlambat" required>
                </td>
            </tr>
            <tr>
                <td>Denda</td>
                <td>:</td>
                <td>
                    <input class="form-control" type="number" name="denda" required>
                </td>
            </tr>
            <tr>
                <td>Buku</td>
                <td>:</td>
                <td>
                <select class="form-control" name="buku_id" required>
                    <?php
                    include "koneksi.php";
                    $sqlbuku=mysqli_query($koneksi,"CALL tampil_buku()");
                    while($row=mysqli_fetch_array($sqlbuku)) {
                        echo "<option>$row[buku_id]-$row[buku_judul]</option>";
                    }
                    ?>
                </select>
                </td>
            </tr>
            <tr>
                <td>Member</td>
                <td>:</td>
                <td>
                <select class="form-control" name="member_id" required>
                    <?php
                    include "koneksi.php";
                    $sqlmember=mysqli_query($koneksi,"CALL tampil_member()");
                    while($row=mysqli_fetch_array($sqlmember)) {
                        echo "<option>$row[member_id]-$row[member_nama]</option>";
                    }
                    ?>
                </select>
                </td>
            </tr>
            <tr>
                <td>Pustakawan</td>
                <td>:</td>
                <td>
                <select class="form-control" name="pustakawan_id" required>
                    <?php
                    include "koneksi.php";
                    $sqlpustakawan=mysqli_query($koneksi,"CALL tampil_pustakawan()");
                    while($row=mysqli_fetch_array($sqlpustakawan)) {
                        echo "<option>$row[pustakawan_id]-$row[pustakawan_nama]</option>";
                    }
                    ?>
                </select>
                </td>
            </tr>
        </table>
    </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Simpan</button>
      </div>
    </div>
  </div>
</div>
<form  method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
    <table class="table l">
      <tr>
        <td><input class="form-control d" type="text" name="caridata" placeholder="Cari Buku..... " required></td>
        <td><button class="btn btn-primary" type="submit" name="btncari">Cari</button></td>
        </tr>
    </table>
        </form>
        <table class="table table-striped table-bordered we" cellpadding="10" >
            <tr >
                <td>NO</td>
                <td>Tanggal Pinjam</td>
                <td>Jumlah Pinjam</td>
                <td>Tanggal Kembali</td>
                <td>Jumlah Kembali</td>
                <td>Lama Pinjam</td>
                <td>Terlambat</td>
                <td>Denda</td>
                <td>Buku</td>
                <td>Member</td>
                <td>Pustakawan</td>
                <td class="y">TINDAKAN</td>
            </tr>
            <?php
                include "koneksi.php";
                $no=0;
                $panggilsql=mysqli_query($koneksi,"CALL tampil_peminjaman()");
                while($data=mysqli_fetch_array($panggilsql)) {
                    $no++;
                    echo "
                    <tr class='h'>
                    <td>$no</td>
                    <td>$data[pinjam_tgl]</td>
                    <td>$data[pinjam_jml]</td>
                    <td>$data[kembali_tgl]</td>
                    <td>$data[kembali_jml]</td>
                    <td>$data[lama_pinjam]</td>
                    <td>$data[terlambat]</td>
                    <td>$data[denda]</td>
                    <td>$data[buku_id]</td>
                    <td>$data[member_id]</td>
                    <td>$data[pustakawan_id]</td>
                    <td>
                    <form method='post' action='editp.php'>
                        <input type='hidden' name='pinjam_id' value='$data[pinjam_id]'>
                        <button class='edit' type='submit'>Edit</button>
                    </form>
                    <form method='post' action='hapusp.php'>
                        <input type='hidden' name='pinjam_id' value='$data[pinjam_id]'>
                        <button class='hapus' type='submit'>Hapus</button>
                    </form>
                    </td>
                    </tr>";
                }
            ?>
            </div>
    </div>
    </section>
    <footer>

    </footer>
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

</body>
</html>