<?php
$koneksi=mysqli_connect("localhost","root","","perpustakaan") or die("gagal mengkoneksikan");
mysqli_select_db($koneksi,"perpustakaan") or die("database tidak ada");