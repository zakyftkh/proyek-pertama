<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="desain.css">
    <link rel="stylesheet" href="css/bootstrap.css">
    
</head>
<body>
    <header class="bg-warning">
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Perpustakaan</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDarkDropdown" aria-controls="navbarNavDarkDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavDarkDropdown">
      <ul class="navbar-nav">
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
           Menu
          </a>
          <ul class="dropdown-menu dropdown-menu-dark">
          <li><a class="dropdown-item" href="dashboard.php">Dashboard</a></li>
            <li><a class="dropdown-item" href="form-buku.php">Buku</a></li>
            <li><a class="dropdown-item" href="form-member.php">Member</a></li>
            <li><a class="dropdown-item" href="form-pustakawan.php">Pustakawan</a></li>
            <li><a class="dropdown-item" href="form-peminjaman.php">Peminjaman</a></li>
          </ul>
        </li>
      </ul>
    </div>
  </div>
</nav>
    </header>
    <section>
    <div class="layer">
        <div class="tb">
        <h2>Data Pustakawan</h2>
<button type="button" class="btn btn-primary tmbl" data-bs-toggle="modal" data-bs-target="#tambah">
  Tambah Pustakawan
</button>
<div class="modal fade" id="tambah" tabindex="-1" aria-labelledby="tambah" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5 judul" id="tambah">Tambah Pustakawan</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <form method="post" action="simpan.php">
        <table class="table" >
            <tr>
                <td>Nama</td>
                <td>:</td>
                <td>
                    <input class="form-control" type="text" name="pustakawan_nama" required>
                </td>
            </tr>
            <tr>
                <td>Jenis Kelamin</td>
                <td>:</td>
                <td>
                    <select class="form-control" name="pustakawan_jenis" required>
                        <option>Laki-laki</option>
                        <option>Perempuan</option>
                    </select>
                </td>
            </tr>
            <tr>
                <td>Alamat</td>
                <td>:</td>
                <td>
                    <input class="form-control" type="text" name="pustakawan_alamat" required>
                </td>
            </tr>
            <tr>
                <td>No Hp</td>
                <td>:</td>
                <td>
                    <input class="form-control" type="number" name="pustakawan_hp" required>
                </td>
            </tr>
            <tr>
                <td>Username</td>
                <td>:</td>
                <td>
                    <input class="form-control" type="text" name="pustakawan_username" required>
                </td>
            </tr>
            <tr>
                <td>Password</td>
                <td>:</td>
                <td>
                    <input class="form-control" type="password" name="pustakawan_password" required>
                </td>
            </tr>
        </table>
    </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Simpan</button>
      </div>
    </div>
  </div>
</div>
<form  method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
    <table class="table l">
      <tr>
        <td><input class="form-control d" type="text" name="caridata" placeholder="Cari Buku..... " required></td>
        <td><button class="btn btn-primary" type="submit" name="btncari">Cari</button></td>
        </tr>
    </table>
        </form>
        <table class="table table-striped we" cellpadding="10" >
            <tr>
                <td>NO</td>
                <td>Nama</td>
                <td>Jenis Kelamin</td>
                <td>Alamat</td>
                <td>No Hp</td>
                <td>Username</td>
                <td>Password</td>
                <td class="y">TINDAKAN</td>
            </tr>
            <?php
                include "koneksi.php";
                $no=0;
                $panggilsql=mysqli_query($koneksi,"CALL tampil_pustakawan()");
                while($data=mysqli_fetch_array($panggilsql)) {
                    $no++;
                    echo "
                    <tr class='h'>
                    <td>$no</td>
                    <td>$data[pustakawan_nama]</td>
                    <td>$data[pustakawan_jenis]</td>
                    <td>$data[pustakawan_alamat]</td>
                    <td>$data[pustakawan_hp]</td>
                    <td>$data[pustakawan_username]</td>
                    <td>$data[pustakawan_password]</td>
                    <td>
                    <form method='post' action='editp.php'>
                        <input type='hidden' name='pustakawan_id' value='$data[pustakawan_id]'>
                        <button class='edit' type='submit'>Edit</button>
                    </form>
                    <form method='post' action='hapusp.php'>
                        <input type='hidden' name='pustakawan_id' value='$data[pustakawan_id]'>
                        <button class='hapus' type='submit'>Hapus</button>
                    </form>
                    </td>
                    </tr>";
                }
            ?>
            </div>
    </div>
    </section>
    <footer>

    </footer>
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

</body>
</html>