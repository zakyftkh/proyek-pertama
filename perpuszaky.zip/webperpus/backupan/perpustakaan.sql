-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 12 Okt 2022 pada 08.52
-- Versi server: 10.1.34-MariaDB
-- Versi PHP: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `perpustakaan`
--

DELIMITER $$
--
-- Prosedur
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `cari_buku` (IN `judul` VARCHAR(100))  NO SQL
SELECT * FROM buku WHERE buku.buku_judul LIKE judul$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `cari_member` (IN `nama` VARCHAR(100))  NO SQL
SELECT * FROM member WHERE member.member_nama LIKE nama$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `cari_peminjaman` (IN `idbuku` INT(11))  NO SQL
SELECT * FROM peminjaman WHERE peminjaman.buku_id LIKE idbuku$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `cari_pustakawan` (IN `nama` VARCHAR(50))  NO SQL
SELECT * FROM pustakawan WHERE pustakawan.pustakawan_nama LIKE nama$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `hapus_buku` (IN `idbuku` INT(11))  NO SQL
DELETE FROM buku WHERE buku.buku_id=idbuku$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `hapus_member` (IN `idmember` INT(11))  NO SQL
DELETE FROM member WHERE member.member_id=idmember$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `hapus_peminjaman` (IN `idpinjam` INT(11))  NO SQL
DELETE FROM peminjaman WHERE peminjaman.pinjam_id=idpinjam$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `hapus_pustakawan` (IN `idpustakawan` INT(11))  NO SQL
DELETE FROM pustakawan WHERE pustakawan.pustakawan_id=idpustakawan$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `tambah_buku` (IN `judul` VARCHAR(100), IN `tgl_stok` DATE, IN `jumlah` INT(10))  NO SQL
INSERT INTO buku (buku.buku_judul,buku.buku_tgl_stok,buku.buku_jumlah)
VALUES (judul,tgl_stok,jumlah)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `tambah_member` (IN `nama` VARCHAR(100), IN `jenis` ENUM('Laki-laki','Perempuan'), IN `tempat` VARCHAR(100), IN `tgl_lh` DATE, IN `hp` CHAR(13))  NO SQL
INSERT INTO member (member.member_nama,member.member_jenis,member.member_tempat_lahir,member.member_tgl_lahir,member.member_hp) VALUES (nama,jenis,tempat,tgl_lh,hp)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `tambah_peminjaman` (IN `tglpinjam` DATE, IN `jmlpinjam` INT(3), IN `tglkembali` DATE, IN `jmlkembali` INT(3), IN `lamapinjam` INT(3), IN `terlambat` INT(3), IN `denda` BIGINT(20), IN `idbuku` INT(11), IN `idmember` INT(11), IN `idpustakawan` INT(11))  NO SQL
INSERT INTO peminjaman (peminjaman.pinjam_tgl,peminjaman.pinjam_jml,peminjaman.kembali_tgl,peminjaman.kembali_jml,peminjaman.lama_pinjam,peminjaman.terlambat,peminjaman.denda,peminjaman.buku_id,peminjaman.member_id,peminjaman.pustakawan_id) VALUES (tglpinjam,jmlpinjam,tglkembali,jmlkembali,lamapinjam,terlambat,denda,idbuku,idmember,idpustakawan)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `tambah_pustakawan` (IN `nama` VARCHAR(100), IN `jenis` ENUM('Laki-laki','Perempuan'), IN `alamat` TEXT, IN `hp` CHAR(13), IN `user` VARCHAR(50), IN `pass` VARCHAR(50))  NO SQL
INSERT INTO pustakawan (pustakawan.pustakawan_nama,pustakawan.pustakawan_jenis,pustakawan.pustakawan_alamat,pustakawan.pustakawan_hp,pustakawan.pustakawan_username,pustakawan.pustakawan_password) VALUES (nama,jenis,alamat,hp,user,pass)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `tampil_buku` ()  NO SQL
SELECT * FROM buku$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `tampil_member` ()  NO SQL
SELECT * FROM member$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `tampil_peminjaman` ()  NO SQL
SELECT buku. * ,member. * ,pustakawan. * ,peminjaman. * FROM buku,member,pustakawan,peminjaman WHERE buku.buku_id=peminjaman.buku_id AND member.member_id=peminjaman.member_id AND pustakawan.pustakawan_id=peminjaman.pustakawan_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `tampil_pustakawan` ()  NO SQL
SELECT * FROM pustakawan$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `update_buku` (IN `idbuku` INT(11), IN `judul` VARCHAR(100), IN `tgl_stok` DATE, IN `jumlah` INT(10))  NO SQL
UPDATE buku SET buku.buku_judul=judul,buku.buku_tgl_stok=tgl_stok,buku.buku_jumlah=jumlah WHERE buku.buku_id=idbuku$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `update_member` (IN `idmember` INT(11), IN `nama` VARCHAR(100), IN `jenis` ENUM('Laki-laki','Perempuan'), IN `tempat` VARCHAR(100), IN `tgl_lh` DATE, IN `hp` CHAR(13))  NO SQL
UPDATE member SET 
member.member_nama=nama,
member.member_jenis=jenis,
member.member_tempat_lahir=tempat,
member.member_tgl_lahir=tgl_lh,
member.member_hp=hp 
WHERE 
member.member_id=idmember$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `update_peminjaman` (IN `idpinjam` MEDIUMINT(15), IN `tglpinjam` DATE, IN `jmlpinjam` INT(3), IN `tglkembali` DATE, IN `jmlkembali` INT(3), IN `lamapinjam` INT(3), IN `terlambat` INT(3), IN `denda` BIGINT(20), IN `idbuku` INT(11), IN `idmember` INT(11), IN `idpustakawan` INT(11))  NO SQL
UPDATE peminjaman SET 
peminjaman.pinjam_tgl=tglpinjam,
peminjaman.pinjam_jml=jmlpinjam,
peminjaman.kembali_tgl=tglkembali,
peminjaman.kembali_jml=jmlkembali,
peminjaman.lama_pinjam=lamapinjam,
peminjaman.terlambat=terlambat,
peminjaman.denda=denda,
peminjaman.buku_id=idbuku,
peminjaman.member_id=idmember,
peminjaman.pustakawan_id=idpustakawan
WHERE 
peminjaman.pinjam_id=idpinjam$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `update_pustakawan` (IN `idpustakawan` INT(11), IN `nama` VARCHAR(100), IN `jenis` ENUM('Laki-laki','Perempuan'), IN `alamat` TEXT, IN `hp` CHAR(13), IN `user` VARCHAR(50), IN `pass` VARCHAR(50))  NO SQL
UPDATE pustakawan SET 
pustakawan.pustakawan_nama=nama,
pustakawan.pustakawan_jenis=jenis,
pustakawan.pustakawan_alamat=alamat,
pustakawan.pustakawan_hp=hp,
pustakawan.pustakawan_username=user,
pustakawan.pustakawan_password=pass
WHERE 
pustakawan.pustakawan_id=idpustakawan$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `buku`
--

CREATE TABLE `buku` (
  `buku_id` int(11) NOT NULL,
  `buku_judul` varchar(100) NOT NULL,
  `buku_tgl_stok` date NOT NULL,
  `buku_jumlah` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `buku`
--

INSERT INTO `buku` (`buku_id`, `buku_judul`, `buku_tgl_stok`, `buku_jumlah`) VALUES
(1, 'Maling kundang', '2022-10-03', 10);

-- --------------------------------------------------------

--
-- Struktur dari tabel `member`
--

CREATE TABLE `member` (
  `member_id` int(11) NOT NULL,
  `member_nama` varchar(100) NOT NULL,
  `member_jenis` enum('Laki-laki','Perempuan') NOT NULL,
  `member_tempat_lahir` varchar(100) NOT NULL,
  `member_tgl_lahir` date NOT NULL,
  `member_hp` char(13) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `member`
--

INSERT INTO `member` (`member_id`, `member_nama`, `member_jenis`, `member_tempat_lahir`, `member_tgl_lahir`, `member_hp`) VALUES
(1, 'Zaky', 'Laki-laki', 'Meteseh', '1945-10-10', '2147483647');

-- --------------------------------------------------------

--
-- Struktur dari tabel `peminjaman`
--

CREATE TABLE `peminjaman` (
  `pinjam_id` mediumint(15) NOT NULL,
  `pinjam_tgl` date NOT NULL,
  `pinjam_jml` int(3) NOT NULL,
  `kembali_tgl` date DEFAULT NULL,
  `kembali_jml` int(3) DEFAULT NULL,
  `lama_pinjam` int(3) DEFAULT NULL,
  `terlambat` int(3) DEFAULT NULL,
  `denda` bigint(20) DEFAULT NULL,
  `buku_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `pustakawan_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `peminjaman`
--

INSERT INTO `peminjaman` (`pinjam_id`, `pinjam_tgl`, `pinjam_jml`, `kembali_tgl`, `kembali_jml`, `lama_pinjam`, `terlambat`, `denda`, `buku_id`, `member_id`, `pustakawan_id`) VALUES
(2, '2020-03-03', 3, '2022-10-01', 3, 3, 3, 20, 1, 1, 1);

--
-- Trigger `peminjaman`
--
DELIMITER $$
CREATE TRIGGER `stok_berkurang` AFTER INSERT ON `peminjaman` FOR EACH ROW UPDATE buku SET buku.buku_jumlah=buku.buku_jumlah-NEW.pinjam_jml WHERE buku.buku_id=NEW.buku_id
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `pustakawan`
--

CREATE TABLE `pustakawan` (
  `pustakawan_id` int(11) NOT NULL,
  `pustakawan_nama` varchar(50) NOT NULL,
  `pustakawan_jenis` enum('Laki-laki','Perempuan') NOT NULL,
  `pustakawan_alamat` text NOT NULL,
  `pustakawan_hp` char(13) NOT NULL,
  `pustakawan_username` varchar(50) NOT NULL,
  `pustakawan_password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pustakawan`
--

INSERT INTO `pustakawan` (`pustakawan_id`, `pustakawan_nama`, `pustakawan_jenis`, `pustakawan_alamat`, `pustakawan_hp`, `pustakawan_username`, `pustakawan_password`) VALUES
(1, 'Angga', 'Laki-laki', 'Meteseh', '812134678', 'Unyel', '12345');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `buku`
--
ALTER TABLE `buku`
  ADD PRIMARY KEY (`buku_id`);

--
-- Indeks untuk tabel `member`
--
ALTER TABLE `member`
  ADD PRIMARY KEY (`member_id`);

--
-- Indeks untuk tabel `peminjaman`
--
ALTER TABLE `peminjaman`
  ADD PRIMARY KEY (`pinjam_id`),
  ADD KEY `buku_id` (`buku_id`),
  ADD KEY `member_id` (`member_id`),
  ADD KEY `pustakawan` (`pustakawan_id`);

--
-- Indeks untuk tabel `pustakawan`
--
ALTER TABLE `pustakawan`
  ADD PRIMARY KEY (`pustakawan_id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `buku`
--
ALTER TABLE `buku`
  MODIFY `buku_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `member`
--
ALTER TABLE `member`
  MODIFY `member_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `peminjaman`
--
ALTER TABLE `peminjaman`
  MODIFY `pinjam_id` mediumint(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `pustakawan`
--
ALTER TABLE `pustakawan`
  MODIFY `pustakawan_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `peminjaman`
--
ALTER TABLE `peminjaman`
  ADD CONSTRAINT `peminjaman_ibfk_1` FOREIGN KEY (`member_id`) REFERENCES `member` (`member_id`),
  ADD CONSTRAINT `peminjaman_ibfk_2` FOREIGN KEY (`pustakawan_id`) REFERENCES `pustakawan` (`pustakawan_id`),
  ADD CONSTRAINT `peminjaman_ibfk_3` FOREIGN KEY (`buku_id`) REFERENCES `buku` (`buku_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
